import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { ArrowRight, Zap, Settings, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export function ConfigurationPage() {
  const [baseUrl, setBaseUrl] = useState('http://localhost:3083');
  const [controllerUrl, setControllerUrl] = useState('');
  const [clientId, setClientId] = useState('');
  const [loading, setLoading] = useState(false);
  const [initialized, setInitialized] = useState(false);

  const handleZeroConfigInit = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setInitialized(true);
      toast.success('DataClient initialized successfully (Zero-Config)', {
        description: 'Configuration fetched from server endpoint',
      });
    } catch (error: any) {
      toast.error('Failed to initialize DataClient', {
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleManualInit = async () => {
    if (!baseUrl) {
      toast.error('Base URL is required');
      return;
    }

    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      setInitialized(true);
      toast.success('DataClient initialized successfully (Manual)', {
        description: 'Custom configuration applied',
      });
    } catch (error: any) {
      toast.error('Failed to initialize DataClient', {
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleTestConnection = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 600));
      toast.success('Connection test successful', {
        description: 'Server is responding normally',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="border-b border-border bg-white">
        <div className="px-8 py-6">
          <h1 className="text-2xl">Configuration</h1>
          <p className="text-muted-foreground mt-1">
            Initialize and configure the Data Client connection
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-8">
        <div className="max-w-4xl space-y-6">
          {/* Status Card */}
          {initialized && (
            <Card className="border-green-200 bg-green-50">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                  <div>
                    <p className="font-medium text-green-900">DataClient Initialized</p>
                    <p className="text-sm text-green-700">Ready to make API requests</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Zero-Config Setup */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Zap className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <CardTitle>Zero-Config Setup</CardTitle>
                  <CardDescription>Automatically fetch configuration from server (Recommended)</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Button
                onClick={handleZeroConfigInit}
                disabled={loading}
                className="w-full"
                size="lg"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Initializing...
                  </>
                ) : (
                  <>
                    Auto-Initialize DataClient
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Manual Configuration */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                  <Settings className="w-5 h-5 text-muted-foreground" />
                </div>
                <div>
                  <CardTitle>Manual Configuration</CardTitle>
                  <CardDescription>Configure DataClient with custom settings</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="baseUrl">Base URL</Label>
                <Input
                  id="baseUrl"
                  type="text"
                  value={baseUrl}
                  onChange={(e) => setBaseUrl(e.target.value)}
                  placeholder="http://localhost:3083"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="controllerUrl">Controller URL (Optional)</Label>
                <Input
                  id="controllerUrl"
                  type="text"
                  value={controllerUrl}
                  onChange={(e) => setControllerUrl(e.target.value)}
                  placeholder="https://miso.aifabrix.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="clientId">Client ID (Optional)</Label>
                <Input
                  id="clientId"
                  type="text"
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  placeholder="Enter client ID"
                />
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={handleManualInit}
                  disabled={loading}
                  variant="secondary"
                  className="flex-1"
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
                      Initializing...
                    </>
                  ) : (
                    'Initialize DataClient'
                  )}
                </Button>
                <Button
                  onClick={handleTestConnection}
                  disabled={loading || !baseUrl}
                  variant="outline"
                >
                  Test Connection
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Connection Info */}
          <Card>
            <CardHeader>
              <CardTitle>Connection Information</CardTitle>
              <CardDescription>Current configuration settings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">Status</span>
                  <span className={initialized ? 'text-green-600 font-medium' : 'text-muted-foreground'}>
                    {initialized ? 'Connected' : 'Not Initialized'}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">Base URL</span>
                  <span className="font-mono text-xs">{baseUrl || 'Not set'}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">Controller URL</span>
                  <span className="font-mono text-xs">{controllerUrl || 'Not set'}</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-muted-foreground">Client ID</span>
                  <span className="font-mono text-xs">{clientId || 'Auto-generated'}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
