import React, { useState, useEffect } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { toast } from 'sonner@2.0.3';
import { Activity, BarChart3, FileText, TrendingUp } from 'lucide-react';

export function MonitoringPage() {
  const [loading, setLoading] = useState(false);
  const [metrics, setMetrics] = useState<any>(null);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);

  useEffect(() => {
    // Load initial metrics
    loadMetrics();
  }, []);

  const loadMetrics = () => {
    setMetrics({
      totalRequests: 1247,
      successfulRequests: 1189,
      failedRequests: 58,
      cacheHits: 342,
      cacheMisses: 905,
      averageResponseTime: 245,
      requestsByEndpoint: {
        '/api/users': 423,
        '/api/products': 312,
        '/api/orders': 289,
        '/api/analytics': 223,
      },
    });
  };

  const testGetMetrics = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      loadMetrics();
      toast.success('Metrics retrieved successfully');
    } finally {
      setLoading(false);
    }
  };

  const testMultipleRequests = async () => {
    setLoading(true);
    try {
      toast.info('Making multiple requests...');
      await new Promise(resolve => setTimeout(resolve, 1200));
      
      const newLogs = [
        { endpoint: '/api/users', status: 200, duration: '120ms', timestamp: new Date().toISOString() },
        { endpoint: '/api/products', status: 200, duration: '89ms', timestamp: new Date().toISOString() },
        { endpoint: '/api/orders', status: 200, duration: '156ms', timestamp: new Date().toISOString() },
        { endpoint: '/api/analytics', status: 200, duration: '234ms', timestamp: new Date().toISOString() },
      ];
      
      setAuditLogs(prev => [...newLogs, ...prev]);
      toast.success('All requests completed successfully', {
        description: 'Total duration: 599ms',
      });
    } finally {
      setLoading(false);
    }
  };

  const testAuditLogging = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 600));
      const newLog = {
        id: 'audit-' + Date.now(),
        action: 'USER_UPDATE',
        user: 'john@example.com',
        timestamp: new Date().toISOString(),
        endpoint: '/api/users/1',
        method: 'PUT',
        status: 200,
      };
      setAuditLogs(prev => [newLog, ...prev]);
      toast.success('Audit log created');
    } finally {
      setLoading(false);
    }
  };

  const clearLogs = () => {
    setAuditLogs([]);
    toast.success('Audit logs cleared');
  };

  const successRate = metrics ? ((metrics.successfulRequests / metrics.totalRequests) * 100).toFixed(1) : 0;
  const cacheHitRate = metrics ? ((metrics.cacheHits / (metrics.cacheHits + metrics.cacheMisses)) * 100).toFixed(1) : 0;

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="border-b border-border bg-white">
        <div className="px-8 py-6">
          <h1 className="text-2xl">Monitoring & Logs</h1>
          <p className="text-muted-foreground mt-1">
            View performance metrics, audit logs, and system health
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-8">
        <div className="max-w-6xl">
          <Tabs defaultValue="metrics" className="space-y-6">
            <TabsList>
              <TabsTrigger value="metrics">Metrics</TabsTrigger>
              <TabsTrigger value="audit">Audit Logs</TabsTrigger>
            </TabsList>

            {/* Metrics Tab */}
            <TabsContent value="metrics" className="space-y-6">
              {/* Action Buttons */}
              <div className="flex gap-2">
                <Button onClick={testGetMetrics} disabled={loading} className="bg-blue-600 hover:bg-blue-700">
                  <Activity className="w-4 h-4 mr-2" />
                  Refresh Metrics
                </Button>
                <Button onClick={testMultipleRequests} disabled={loading} className="bg-green-600 hover:bg-green-700">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Make Multiple Requests
                </Button>
              </div>

              {/* Metrics Cards */}
              {metrics && (
                <>
                  <div className="grid grid-cols-4 gap-4">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-semibold">{metrics.totalRequests}</div>
                        <div className="text-sm text-muted-foreground mt-1">Total Requests</div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-semibold text-green-600">{successRate}%</div>
                        <div className="text-sm text-muted-foreground mt-1">Success Rate</div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-semibold text-blue-600">{cacheHitRate}%</div>
                        <div className="text-sm text-muted-foreground mt-1">Cache Hit Rate</div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-semibold">{metrics.averageResponseTime}ms</div>
                        <div className="text-sm text-muted-foreground mt-1">Avg Response Time</div>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Request Status</CardTitle>
                        <CardDescription>Breakdown by success/failure</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Successful</span>
                            <span className="text-sm font-medium text-green-600">{metrics.successfulRequests}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Failed</span>
                            <span className="text-sm font-medium text-red-600">{metrics.failedRequests}</span>
                          </div>
                          <div className="flex justify-between items-center pt-2 border-t border-border">
                            <span className="text-sm font-medium">Total</span>
                            <span className="text-sm font-medium">{metrics.totalRequests}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Cache Performance</CardTitle>
                        <CardDescription>Cache hits vs misses</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Cache Hits</span>
                            <span className="text-sm font-medium text-green-600">{metrics.cacheHits}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Cache Misses</span>
                            <span className="text-sm font-medium text-orange-600">{metrics.cacheMisses}</span>
                          </div>
                          <div className="flex justify-between items-center pt-2 border-t border-border">
                            <span className="text-sm font-medium">Hit Rate</span>
                            <span className="text-sm font-medium text-blue-600">{cacheHitRate}%</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Requests by Endpoint</CardTitle>
                      <CardDescription>Most frequently accessed endpoints</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {Object.entries(metrics.requestsByEndpoint).map(([endpoint, count]) => (
                          <div key={endpoint} className="flex items-center gap-3">
                            <div className="flex-1">
                              <div className="text-sm font-mono">{endpoint}</div>
                              <div className="h-2 bg-muted rounded-full mt-1">
                                <div
                                  className="h-full bg-blue-500 rounded-full"
                                  style={{ width: `${((count as number) / metrics.totalRequests) * 100}%` }}
                                />
                              </div>
                            </div>
                            <div className="text-sm font-medium w-16 text-right">{count as number}</div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </TabsContent>

            {/* Audit Logs Tab */}
            <TabsContent value="audit" className="space-y-6">
              <div className="flex justify-between items-center">
                <div className="flex gap-2">
                  <Button onClick={testAuditLogging} disabled={loading}>
                    <FileText className="w-4 h-4 mr-2" />
                    Create Audit Log
                  </Button>
                  <Button onClick={testMultipleRequests} disabled={loading} className="bg-green-600 hover:bg-green-700">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Make Multiple Requests
                  </Button>
                </div>
                {auditLogs.length > 0 && (
                  <Button onClick={clearLogs} variant="outline" size="sm">
                    Clear Logs
                  </Button>
                )}
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Audit Log Entries</CardTitle>
                  <CardDescription>Recent activity and requests</CardDescription>
                </CardHeader>
                <CardContent>
                  {auditLogs.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      No audit logs yet. Make some requests to see logs here.
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {auditLogs.map((log, index) => (
                        <div key={index} className="p-3 bg-muted rounded-lg text-sm">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-mono text-xs">{log.endpoint}</span>
                            <span className="text-xs text-muted-foreground">
                              {new Date(log.timestamp).toLocaleTimeString()}
                            </span>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>Method: <span className="font-medium">{log.method || 'GET'}</span></span>
                            <span>Status: <span className={`font-medium ${log.status === 200 ? 'text-green-600' : 'text-red-600'}`}>{log.status}</span></span>
                            <span>Duration: <span className="font-medium">{log.duration}</span></span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
