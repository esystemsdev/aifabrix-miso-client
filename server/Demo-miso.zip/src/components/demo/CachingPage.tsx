import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { toast } from 'sonner@2.0.3';
import { Clock, Database, Trash2, RefreshCw } from 'lucide-react';

export function CachingPage() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [cacheTTL, setCacheTTL] = useState('60000');
  const [cacheKey, setCacheKey] = useState('');

  const testCacheEnabled = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 400));
      setResult({
        data: { users: [{ id: 1, name: 'Cached User' }] },
        cached: true,
        cacheKey: 'GET:/api/users',
        ttl: cacheTTL + 'ms',
        timestamp: new Date().toISOString(),
      });
      toast.success('Data retrieved from cache', {
        description: 'Response served instantly from cache',
      });
    } finally {
      setLoading(false);
    }
  };

  const testCacheDisabled = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      setResult({
        data: { users: [{ id: 1, name: 'Fresh User' }] },
        cached: false,
        timestamp: new Date().toISOString(),
      });
      toast.success('Fresh data retrieved', {
        description: 'Cache bypassed, fetched from server',
      });
    } finally {
      setLoading(false);
    }
  };

  const testClearCache = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      setResult({
        message: 'Cache cleared successfully',
        entriesCleared: 12,
        freedMemory: '2.4 MB',
      });
      toast.success('Cache cleared', {
        description: '12 cache entries removed',
      });
    } finally {
      setLoading(false);
    }
  };

  const testClearSpecificKey = async () => {
    if (!cacheKey) {
      toast.error('Please enter a cache key');
      return;
    }
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      setResult({
        message: `Cache key cleared: ${cacheKey}`,
        key: cacheKey,
      });
      toast.success('Specific cache entry cleared');
    } finally {
      setLoading(false);
    }
  };

  const testInterceptors = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      setResult({
        interceptor: 'request',
        originalRequest: {
          url: '/api/users',
          method: 'GET',
        },
        modifiedRequest: {
          url: '/api/users',
          method: 'GET',
          headers: {
            'X-Custom-Header': 'intercepted',
            'Cache-Control': 'max-age=3600',
          },
        },
      });
      toast.success('Request interceptor applied');
    } finally {
      setLoading(false);
    }
  };

  const testRetryLogic = async () => {
    setLoading(true);
    try {
      toast.info('Attempting request with retries...');
      await new Promise(resolve => setTimeout(resolve, 1500));
      setResult({
        retries: 3,
        attempts: [
          { attempt: 1, delay: '100ms', status: 'failed' },
          { attempt: 2, delay: '200ms', status: 'failed' },
          { attempt: 3, delay: '400ms', status: 'success' },
        ],
        finalStatus: 'success',
      });
      toast.success('Request succeeded after 3 retries');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="border-b border-border bg-white">
        <div className="px-8 py-6">
          <h1 className="text-2xl">Caching & Storage</h1>
          <p className="text-muted-foreground mt-1">
            Test caching mechanisms, interceptors, and retry logic
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-8">
        <div className="max-w-6xl space-y-6">
          {/* Cache Operations */}
          <div className="grid grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                    <Database className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Cache Enabled</CardTitle>
                    <CardDescription>Retrieve data with caching</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="cacheTTL">Cache TTL (milliseconds)</Label>
                  <Input
                    id="cacheTTL"
                    type="number"
                    value={cacheTTL}
                    onChange={(e) => setCacheTTL(e.target.value)}
                    placeholder="60000"
                  />
                </div>
                <Button onClick={testCacheEnabled} disabled={loading} className="w-full bg-green-600 hover:bg-green-700">
                  <Database className="w-4 h-4 mr-2" />
                  GET with Cache
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <RefreshCw className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Cache Bypassed</CardTitle>
                    <CardDescription>Fetch fresh data from server</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Button onClick={testCacheDisabled} disabled={loading} className="w-full bg-blue-600 hover:bg-blue-700">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  GET without Cache
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Cache Management */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Cache Management</CardTitle>
              <CardDescription>Clear cache entries</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Button onClick={testClearCache} disabled={loading} variant="outline" className="border-orange-200 text-orange-700 hover:bg-orange-50">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Clear All Cache
                </Button>
              </div>

              <div className="pt-4 border-t border-border space-y-3">
                <Label htmlFor="cacheKey">Clear Specific Cache Key</Label>
                <div className="flex gap-2">
                  <Input
                    id="cacheKey"
                    type="text"
                    value={cacheKey}
                    onChange={(e) => setCacheKey(e.target.value)}
                    placeholder="GET:/api/users"
                    className="flex-1"
                  />
                  <Button onClick={testClearSpecificKey} disabled={loading} variant="secondary">
                    Clear
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Advanced Features */}
          <div className="grid grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Request Interceptors</CardTitle>
                <CardDescription>Modify requests before sending</CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={testInterceptors} disabled={loading} className="w-full">
                  Test Request Interceptor
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Retry Logic</CardTitle>
                <CardDescription>Automatic retry on failures</CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={testRetryLogic} disabled={loading} className="w-full">
                  Test Retry Mechanism
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Result Panel */}
          {result && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Response</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="text-xs bg-muted p-4 rounded-lg overflow-x-auto">
                  {JSON.stringify(result, null, 2)}
                </pre>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
