import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { toast } from 'sonner@2.0.3';

export function ApiTestingPage() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const executeRequest = async (method: string, endpoint: string, mockData: any) => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 600));
      setResult({
        method,
        endpoint,
        status: 200,
        timestamp: new Date().toISOString(),
        data: mockData,
      });
      toast.success(`${method} ${endpoint} successful`);
    } catch (error: any) {
      toast.error('Request failed', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  // HTTP Methods Tests
  const testGet = () => executeRequest('GET', '/api/users', {
    users: [
      { id: 1, name: 'John Doe', email: 'john@example.com' },
      { id: 2, name: 'Jane Smith', email: 'jane@example.com' },
    ],
  });

  const testGetById = () => executeRequest('GET', '/api/users/1', {
    id: 1,
    name: 'John Doe',
    email: 'john@example.com',
    role: 'admin',
  });

  const testPost = () => executeRequest('POST', '/api/users', {
    id: 3,
    name: 'New User',
    email: 'newuser@example.com',
    created: new Date().toISOString(),
  });

  const testPut = () => executeRequest('PUT', '/api/users/1', {
    id: 1,
    name: 'John Doe Updated',
    email: 'john.updated@example.com',
    updated: new Date().toISOString(),
  });

  const testPatch = () => executeRequest('PATCH', '/api/users/1', {
    id: 1,
    email: 'john.patched@example.com',
    updated: new Date().toISOString(),
  });

  const testDelete = () => executeRequest('DELETE', '/api/users/1', {
    message: 'User deleted successfully',
    id: 1,
  });

  // Authentication Tests
  const testIsAuthenticated = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      const isAuth = true;
      setResult({
        authenticated: isAuth,
        timestamp: new Date().toISOString(),
      });
      toast.success('User is authenticated');
    } finally {
      setLoading(false);
    }
  };

  const testGetToken = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      setResult({
        token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
        expiresAt: new Date(Date.now() + 3600000).toISOString(),
      });
      toast.success('Token retrieved successfully');
    } finally {
      setLoading(false);
    }
  };

  const testLogout = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      setResult({ message: 'User logged out successfully' });
      toast.success('Logged out successfully');
    } finally {
      setLoading(false);
    }
  };

  // Error Handling Tests
  const testNetworkError = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      setResult({
        error: 'Network Error',
        type: 'NETWORK_ERROR',
        message: 'Failed to connect to server',
      });
      toast.error('Network error simulated');
    } finally {
      setLoading(false);
    }
  };

  const testTimeout = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setResult({
        error: 'Request Timeout',
        type: 'TIMEOUT_ERROR',
        message: 'Request exceeded 5000ms timeout',
      });
      toast.error('Request timeout simulated');
    } finally {
      setLoading(false);
    }
  };

  const testApiError = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 600));
      setResult({
        error: 'Bad Request',
        status: 400,
        details: {
          email: ['Invalid email format'],
          password: ['Password must be at least 8 characters'],
        },
      });
      toast.error('API error (400) simulated');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="border-b border-border bg-white">
        <div className="px-8 py-6">
          <h1 className="text-2xl">API Testing</h1>
          <p className="text-muted-foreground mt-1">
            Test HTTP methods, authentication, and error handling
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-8">
        <div className="max-w-6xl">
          <Tabs defaultValue="http" className="space-y-6">
            <TabsList>
              <TabsTrigger value="http">HTTP Methods</TabsTrigger>
              <TabsTrigger value="auth">Authentication</TabsTrigger>
              <TabsTrigger value="errors">Error Handling</TabsTrigger>
            </TabsList>

            {/* HTTP Methods Tab */}
            <TabsContent value="http" className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">GET Requests</CardTitle>
                    <CardDescription>Retrieve data from the server</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button onClick={testGet} disabled={loading} className="w-full bg-green-600 hover:bg-green-700">
                      GET /api/users
                    </Button>
                    <Button onClick={testGetById} disabled={loading} className="w-full bg-green-600 hover:bg-green-700">
                      GET /api/users/:id
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">POST Requests</CardTitle>
                    <CardDescription>Create new resources</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={testPost} disabled={loading} className="w-full bg-blue-600 hover:bg-blue-700">
                      POST /api/users
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">PUT Requests</CardTitle>
                    <CardDescription>Update existing resources</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={testPut} disabled={loading} className="w-full bg-orange-600 hover:bg-orange-700">
                      PUT /api/users/:id
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">PATCH Requests</CardTitle>
                    <CardDescription>Partially update resources</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={testPatch} disabled={loading} className="w-full bg-orange-600 hover:bg-orange-700">
                      PATCH /api/users/:id
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">DELETE Requests</CardTitle>
                    <CardDescription>Remove resources</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={testDelete} disabled={loading} variant="destructive" className="w-full">
                      DELETE /api/users/:id
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Authentication Tab */}
            <TabsContent value="auth" className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Check Authentication</CardTitle>
                    <CardDescription>Verify user authentication status</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={testIsAuthenticated} disabled={loading} className="w-full">
                      isAuthenticated()
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Get Token</CardTitle>
                    <CardDescription>Retrieve environment token</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={testGetToken} disabled={loading} className="w-full">
                      getEnvironmentToken()
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Logout</CardTitle>
                    <CardDescription>End user session</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={testLogout} disabled={loading} variant="destructive" className="w-full">
                      logout()
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Error Handling Tab */}
            <TabsContent value="errors" className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Network Error</CardTitle>
                    <CardDescription>Simulate connection failure</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={testNetworkError} disabled={loading} variant="destructive" className="w-full">
                      Test Network Error
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Timeout Error</CardTitle>
                    <CardDescription>Simulate request timeout</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={testTimeout} disabled={loading} variant="destructive" className="w-full">
                      Test Timeout
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">API Error (400)</CardTitle>
                    <CardDescription>Simulate validation error</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={testApiError} disabled={loading} variant="destructive" className="w-full">
                      Test API Error
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>

          {/* Result Panel */}
          {result && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-lg">Response</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="text-xs bg-muted p-4 rounded-lg overflow-x-auto">
                  {JSON.stringify(result, null, 2)}
                </pre>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
